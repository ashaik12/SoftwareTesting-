package edu.depaul.se433.functional;

/**
 * Exception thrown by Engine for invalid state
 * transitions
 */
public class InvalidTransitionException extends RuntimeException {

}
