package edu.depaul.se433.functional;

import static edu.depaul.se433.functional.DateObj.makeDate;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.MethodSource;

public class DateObjCsvTest {

  @ParameterizedTest
  @CsvFileSource(resources = "/dates.csv", numLinesToSkip = 1)
  void compareDates(String todayString, String expectedString) {
    DateObj today = makeDate(todayString);
    DateObj expected = makeDate(expectedString);
    assertFalse(expected == today.nextDate()); 
  }
  @ParameterizedTest
  @MethodSource("paramsPass")
  void testIsNextDate(DateObj today, DateObj expectedTomorrow) {
      String actualTomorrow = today.nextDate().toString();
      assertFalse(expectedTomorrow.toString()== actualTomorrow.toString());
  }

  private static Stream<Arguments> paramsPass() { 
      return Stream.of(
              Arguments.of(new DateObj(2019, 4, 25), new DateObj(2019, 4, 26)),
              Arguments.of(new DateObj(2019, 4, 15), new DateObj(2019, 4, 16)),
              Arguments.of(new DateObj(2019, 4, 26), new DateObj(2019, 4, 27)),
              Arguments.of(new DateObj(2019, 3, 31), new DateObj(2019, 4, 1)),
              Arguments.of(new DateObj(2019, 12, 31), new DateObj(2020, 1, 1)),
              Arguments.of(new DateObj(2019, 5, 30), new DateObj(2019, 6, 1)),
              Arguments.of(new DateObj(2020, 12, 17), new DateObj(2020, 12, 18)),
              Arguments.of(new DateObj(2016, 12, 31), new DateObj(2017, 1, 1)),
              Arguments.of(new DateObj(2019, 3, 13), new DateObj(2019, 3, 14)),
              Arguments.of(new DateObj(2018, 2, 28), new DateObj(2018, 2, 29)));
      }


  public class DateObjTest {

  	@Test
  	@Disabled
  	@DisplayName("Constructor should throw an exception on bad Feb 29")
  	void testConstructorBadFeb() {
  		assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 2, 29));

  	}
  	@Test
  	//@Disabled
  	@DisplayName("Constructor should throw an error for month higher than december")
  	void testConstructorMonth13() {
  		assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 13, 13));

  	}

  	@Test
  	//@Disabled
  	@DisplayName("Constructor should test next year day by comparing from previous day")
  	void testConstructorNextYer() {
  		DateObj day = new DateObj(2019, 12, 31);
  		DateObj nDay = day.nextDate();
  		assertFalse((nDay == day));
  		
  	}
  	@Test
  	@DisplayName("Test next date on a month with 30 days")
  	void testConstructor30Days() {
  		assertFalse(new DateObj(2019,10,1) == new DateObj(2019, 9, 30).nextDate());
  	}
  	@Test
  	@DisplayName("Test next date on a month with 31 days")
  	void testConstructor31Days() {
  		assertFalse(new DateObj(2019,11,1) == new DateObj(2019, 11, 31).nextDate());
  	}
  	@Test
  	@DisplayName("Test next date on leap year")
  	void testConstructorLeapYear() {
  		assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 2, 29));
  	}

  	
  	@Test
  	//@Disabled
  	@DisplayName("Constructor should test next year Day ")
  	void testConstructorNextYear() {
  		DateObj day = new DateObj(2019, 12, 31);
  		DateObj nDay = day.nextDate();
  		assertTrue((nDay != day));
  	}
  	@Test
  	//@Disabled
  	@DisplayName("lowest valid year")
  	void testLowestYear() {
  		DateObj day = new DateObj(1, 1, 1);
  		assertEquals(1, day.getMonth());
  	}


  	@Test
  	//@Disabled
  	@DisplayName("Constructor should throw  an error for day too high")
  	void testConstructorDay32() {
  		assertAll (
  				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 1, 32)),
  				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 2, 32)),
  				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 3, 32)),
  				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 4, 32)),
  				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 5, 32)),
  				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 6, 32)),
  				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 7, 32)),
  				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 8, 32)),
  				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 9, 32)),
  				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 10, 32)),
  				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 11, 32)),
  				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 12, 32)));

  	}
  	@Test
	@DisplayName("Constructor should throw  an error for day when 0")
	void testConstructorDayZero() {
		assertAll (
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 1, 0)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 2, 0)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 3, 0)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 4, 0)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 5, 0)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 6, 0)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 7, 0)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 8, 0)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 9, 0)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 10, 0)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 11, 0)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 12, 0))
				);
	}
	@Test
	@DisplayName("Constructor should throw  an error for month when 0")
	void testConstructorMonthZero() {
		assertAll (
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 0, 3)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2016, 0, 2)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2006, 0, 4)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2033, 0, 5)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2045, 0, 6)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2020, 0, 7))
				);
	}
	
	@Test
	@DisplayName("Constructor should throw  an error for year when 0")
	void testConstructorYearZero() {
		assertAll (
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(0, 11, 12)));
  }
  }}



