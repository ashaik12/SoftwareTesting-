package edu.depaul.triangle;

import java.util.Scanner;

/**
 * A class to classify a set of side lengths as one of the 3 types
 * of triangle: equilateral, isosceles, or scalene.
 * If classification is not possible it emits an error message
 */
public class Triangle {
	
	/**
	 * Define as private so that it is not a valid
	 * choice.
	 */
	private Triangle() {}
	
	public Triangle(String[] args) {
		//
		// TODO: keep this simple.  Constructors should not do a lot of work
		//
		try{
			if(args.length==3) {

			int sideA = Integer.parseInt(args[0]);

			int sideB = Integer.parseInt(args[1]);

			int sideC = Integer.parseInt(args[2]);

			if(sideA <=300 && sideA>=0 && sideB <=300 && sideB>=0 && sideC <=300 && sideC>=0) {

				classify(sideA,sideB,sideC);

			}

			else {

				System.out.println("Enter length between 0 and 300");

			}

		}

	}

	catch (Exception e) {

		System.out.println("An exception occurred, Enter integers only!");

		if(args.length==0) {

			main(args);

		}

	}

}



public static void classify(int sideA, int sideB, int sideC) {

	if(sideA+sideB>sideC && sideA+sideC>sideB && sideB+sideC>sideA) {

		System.out.println("This is a Triangle");

	

		if(sideA==sideB && sideB==sideC)

			System.out.println("Equilateral");



		else if ((sideA==sideB && sideB!=sideC ) || (sideA!=sideB && sideC==sideA) || (sideC==sideB && sideC!=sideA))

			System.out.println("Isosceles");



		else if(sideA!=sideB && sideB!=sideC && sideC!=sideA)

			System.out.println("Scalene");

	}

	else {

		System.out.println("Not a triangle");

	}

}
	
	private static String[] getArgs(Scanner s) {
		System.out.println("press Enter by itself to quit");
		System.out.println("enter 3 integers separated by space.");
		String args = s.nextLine();
		return args.split(" ");
	}
	
	public static void main(String[] a) {

		try (Scanner scanner = new Scanner(System.in)) {
			String[] args = getArgs(scanner);

			// Loop until the user enters an empty line
			while(args[0].length() !=0) {
				//
				// TODO: create a new Triangle here and call it
				//
				Triangle triangle = new Triangle(args);
				args = getArgs(scanner);
			}
			System.out.println("Done");
		}
	}
}
