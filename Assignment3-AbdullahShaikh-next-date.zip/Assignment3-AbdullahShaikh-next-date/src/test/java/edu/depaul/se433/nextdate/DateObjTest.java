package edu.depaul.se433.nextdate;

import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DateObjTest {

	@Test
	//@Disabled
	@DisplayName("Constructor should throw an exception on bad Feb 29")
	void testConstructorBadFeb() {
		assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 2, 29));

	}
	@Test
	//@Disabled
	@DisplayName("Constructor should throw an error for month too high")
	void testConstructorMonth13() {
		assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 13, 13));

	}

	@Test
	//@Disabled
	@DisplayName("lowest valid year")
	void testLowestYear() {
		DateObj day = new DateObj(1, 1, 1);
		assertEquals(1, day.getMonth());
	}

	@Test
	//@Disabled
	@DisplayName("Constructor should throw  an error for year too high")
	void testConstructoryear() {
		assertThrows(IllegalArgumentException.class, () -> new DateObj(9999, 13, 13));

	}

	@Test
	//@Disabled
	@DisplayName("Constructor should throw  an error for day too high")
	void testConstructorDay32() {
		assertAll (
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 1, 32)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 2, 32)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 3, 32)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 4, 32)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 5, 32)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 6, 32)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 7, 32)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 8, 32)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 9, 32)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 10, 32)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 11, 32)),
				() -> assertThrows(IllegalArgumentException.class, () -> new DateObj(2019, 12, 32)));

	}

	

	@Test
	//@Disabled
	@DisplayName("Constructor should test next year for 2019")
	void testConstructorNextYear() {
		DateObj day = new DateObj(2019, 12, 31);
		DateObj nDay = day.nextDate();
		assertTrue((nDay != day));

	}

	@Test
	//@Disabled
	@DisplayName("Constructor should test next year for 2019")
	void testConstructorNextYer() {
		DateObj day = new DateObj(2019, 12, 31);
		DateObj nDay = day.nextDate();
		assertFalse((nDay == day));

	}

	

	

}
	