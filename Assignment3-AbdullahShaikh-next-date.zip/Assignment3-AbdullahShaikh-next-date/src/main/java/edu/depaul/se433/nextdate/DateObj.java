package edu.depaul.se433.nextdate;


/**
 * Implements a next date function for the sake of learning
 * unit test strategies.
 */
public class DateObj {
	
	private int year;
	private int month;
	private int day;
	private int[] monthLengths = new int[] {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	
	public DateObj(int year, int month, int day) {
		this.year = year;
		this.month = month;
		this.day = day;
		validate();
	}
	public DateObj nextDate() {
		DateObj d = new DateObj(year, month, day);
		//leap year

		if (month == 2 && day == monthLengths[month-1]  && year % 4 == 0 ) {

			day = day+1;

			}

		//next year

		else if(month == 12 && day == monthLengths[month-1]){

			month = 1;

			year = year+1;

			day = 1;

			}

		//next month

		else if (day >= monthLengths[month-1]) {

			month = month + 1;

			day=1;

			}

		//next day

		else {

			day = day +1;

			}

		return d;

		}



	@Override

	public String toString() {

		return String.format("Date[year: %d, month: %d, day: %d]", year, month, day);

	}

	public static void main(String[] args) {

		DateObj j = new DateObj(2018, 2, 2);

		for (int i = 0; i <1; i++) {

			j.nextDate();

			System.out.println(j.toString());

			}

		}



	private void validate() {

		if (month < 1 || month > 12)

			throw new IllegalArgumentException("month ("+ month + ") must be 1-12");

		if (day <= 0 ||

			(day > monthLengths[month-1] && !(month == 2 && day == 29 && month % 4 == 0)))

				throw new IllegalArgumentException("day ("+ day +") out-of-range for the specified month and year");

		
		if (month == 2 && day == 29 && !(year % 4 == 0))

			throw new IllegalArgumentException("day ("+ day + ") out-of-range for the specified month and year");

	}
	public Object getMonth() {
		return month;
	}

}